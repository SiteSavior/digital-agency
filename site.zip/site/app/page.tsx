import Image from 'next/image'

import React from "react";
import { FaLaptopCode, FaPhone, FaUser } from 'react-icons/fa';
import Slide from './components/Slide';
import { MdEmail, MdOutlineVerified, MdPhone } from 'react-icons/md';
import Form from './components/Form';
import Foot1 from './components/Foot1';
import Section2 from './components/Section2';
import AnimatedCursor from 'react-animated-cursor';
import Part from '@/app/components/Partical1'
import { Parallax } from 'react-scroll-parallax';
import MainSection from './components/MainSection';


export default function Home() {
 
 
  return (
    <main className="tracking-wider bg-gray-100 z-50">
      
      <div className="App">
      <AnimatedCursor
  innerSize={8}
  outerSize={35}
  innerScale={1}
  outerScale={1.7}
  outerAlpha={0}
  outerStyle={{
    border: '3px solid var(--cursor-color)'
  }}
  innerStyle={{
    backgroundColor: 'var(--cursor-color)'
  }}
/>
    </div>
    <MainSection/>
  
    </main>
  )
}
