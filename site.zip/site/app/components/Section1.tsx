'use client'
import { motion, useScroll, useTransform } from 'framer-motion';
import Image from 'next/image';
import React from 'react'

const Section1 = () => {
    const { scrollYProgress } = useScroll()
const scale = useTransform(scrollYProgress, [0, 1], [0.2, 2]);
  return (
    <div>
        <motion.div
    style={{ scale }}
  >
    <motion.div
      style={{
        scaleY: scrollYProgress
      }}
    />
    
  </motion.div>
    </div>
  )
}

export default Section1
