'use client'
import React from 'react'
import Image from 'next/image'
import { Parallax, ParallaxProvider } from 'react-scroll-parallax'
import { FaPhone } from 'react-icons/fa'
import { MdOutlineVerified } from 'react-icons/md'
import Section2 from './Section2'
import Foot1 from './Foot1'
import Form from './Form'
import Slide from './Slide'
import Faq from './Faq'

const MainSection = () => {
  return (
    <div>
   <section className=''><Slide/></section>
   <section className='border-t-2 border-black pt-24 leading-10'>
     <div className='text-center'>OUR BEST SERVICES</div>
     <div className='text-6xl  text-gray-800 text-center font-bold'>We Provide Best Services</div>
   </section>
   <ParallaxProvider>
   <section className='p-11 flex justify-center items-center mx-auto '>
   <Parallax speed={-10}>
     <div className='flex gap-6 p-11'>
     <div className='bg-white hover:bg-green-600 text-black rounded-3xl drop-shadow-2xl border border-black w-auto'>
       <div className=' w-full'>
       <Image className='h-72 w-full  rounded-t-3xl'
       src={'/image6.avif'}
       width={400}
       height={600}
       alt='web'
       />
       </div>
       <div className='text-3xl px-8  pt-11 font-semibold'>Website Design & Development</div>
       <div className='w-72 text-sm p-8'>We are 100+ professional software engineers with more than 10 years of experience in delivering superior products Believe it because you've seen it. Here are real numbers</div>
       <div></div>
   </div>
   <div className='bg-black text-white rounded-3xl drop-shadow-2xl border border-black w-auto'>
       <div className=' w-full'>
       <Image className='h-72 w-full  rounded-t-3xl'
       src={'/image5.webp'}
       width={400}
       height={600}
       alt='web'
       />
       </div>
       <div className='text-3xl px-8  pt-11 font-semibold'>Search Engine Optimization</div>
       <div className='w-72 text-sm p-8'>We are 100+ professional software engineers with more than 10 years of experience in delivering superior products Believe it because you've seen it. Here are real numbers</div>
       <div></div>
   </div>
   <div className='bg-white text-black rounded-3xl drop-shadow-2xl border border-black w-auto'>
       <div className=' w-full'>
       <Image className='h-72 w-full  rounded-t-3xl'
       src={'/image3.webp'}
       width={400}
       height={600}
       alt='web'
       />
       </div>
       <div className='text-3xl px-8  pt-11 font-semibold'>Paid Ads Promotion</div>
       <div className='w-72 text-sm p-8'>We are 100+ professional software engineers with more than 10 years of experience in delivering superior products Believe it because you've seen it. Here are real numbers</div>
       <div></div>
   </div>

   <div className='bg-black  text-white rounded-3xl drop-shadow-2xl border border-black w-auto'>
       <div className=' w-full'>
       <Image className='h-72 w-full  rounded-t-3xl'
       src={'/image4.avif'}
       width={400}
       height={600}
       alt='web'
       />
       </div>
       <div className='text-3xl px-8  pt-11 font-semibold'>Graphic Design</div>
       <div className='w-72 text-sm p-8'>We are 100+ professional software engineers with more than 10 years of experience in delivering superior products Believe it because you've seen it. Here are real numbers</div>
       <div></div>
   </div>

   <div className='bg-white  text-black rounded-3xl drop-shadow-2xl border border-black w-auto'>
       <div className=' w-full'>
       <Image className='h-72 w-full  rounded-t-3xl'
       src={'/smo.avif'}
       width={400}
       height={600}
       alt='web'
       />
       </div>
       <div className='text-3xl px-8  pt-11 font-semibold'>Social Media Optimization</div>
       <div className='w-72 text-sm p-8'>We are 100+ professional software engineers with more than 10 years of experience in delivering superior products Believe it because you've seen it. Here are real numbers</div>
       <div></div>
   </div>
   </div>
   </Parallax>
   </section>
  
 </ParallaxProvider>
     <section>
       <div className='grid grid-cols-2 p-11 justify-between border-t border-black'>
         <div className='flex flex-col gap-4 justify-center p-24'>
           <div>
           Our Service
           </div>
         <div className='text-5xl text-gray-900 font-bold'>We Provide </div>
         <div className='text-5xl text-gray-900 font-bold'>Better Services?</div>

         </div>
         <div className='flex flex-col gap-8 text-sm'><div className='flex gap-4 items-center'> 
         <div className='flex flex-col gap-2 p-6 items-center justify-center border border-gray-200 rounded-md'> 
     
          <Image
       src={'/elem.webp'}
       width={80}
       height={80}
       alt='web'
       />
       <p>WEB DESIGN</p>
       </div>

       <div className='flex flex-col gap-2 p-6 items-center justify-center border border-gray-200 rounded-md'>  <Image
       src={'/html.webp'}
       width={80}
       height={80}
       alt='web'
       />
       <p>HTML5</p>
       </div>

       <div className='flex flex-col gap-2 p-6 items-center justify-center border border-gray-200 rounded-md'>  <Image
       src={'/wordpress.webp'}
       width={80}
       height={80}
       alt='web'
       />
       <p>WORDPRESS</p>
       </div>
       </div>
       <div className='flex gap-4 items-center'> 
         <div className='flex flex-col gap-2 p-6 items-center justify-center border border-gray-200 rounded-md'> 
         
          <Image
       src={'/react.webp'}
       width={80}
       height={80}
       alt='web'
       />
       <p>REACT</p>
       </div>

       <div className='flex flex-col gap-2 p-6 items-center justify-center border border-gray-200 rounded-md'>  <Image
       src={'/css.webp'}
       width={80}
       height={80}
       alt='web'
       />
       <p>CSS3</p>
       </div>

       <div className='flex flex-col gap-2 p-6 items-center justify-center border border-gray-200 rounded-md'>  <Image
       src={'/java.webp'}
       width={80}
       height={80}
       alt='web'
       />
       <p>JAVASCRIPT</p>
       </div>
       </div>
       </div>

       
       </div>
     </section>
<section className='pt-11 border-t border-black'>
 <div className='grid grid-cols-2 p-24'>
   <div className='flex flex-col gap-8 p-24'>
   <div className='text-5xl text-gray-900 font-bold'>
   Why You Should Choose
<p>Our Services</p>
   </div>
   <div className='gray-700 w-1/2'>We are 100+ professional software engineers with more than 10 years of experience in delivering superior products Believe it because you've seen it. Here are real numbers</div>
   <div className='flex gap-8'>
   <div className='flex items-center gap-2'><MdOutlineVerified className='text-green-700 text-xl' />Fast Working Process</div>
   <div className='flex items-center gap-2'><MdOutlineVerified className='text-green-700 text-xl' />Dedicated Team</div>
   </div>
   <div className='flex gap-8'>
   <div className='flex items-center gap-2'><MdOutlineVerified className='text-green-700 text-xl' />Fast Working Process</div>
   <div className='flex items-center gap-2'><MdOutlineVerified className='text-green-700 text-xl' />Dedicated Team</div>
   </div>
   <div><div><button className='bg-purple-700 text-white hover:bg-red-500 text-sm py-4 px-11 rounded-3xl'>Get a Quote</button></div></div>
   </div>
   <div> <Image
       src={'/image7.jpg'}
       width={600}
       height={400}
       alt='web'
       /></div>
 </div>
</section>
    
     <section>
       <div className='grid grid-cols-2 p-24 border-t border-black'>
         <div className='flex justify-center items-center'>
         <Image
       src={'/png2.webp'}
       width={500}
       height={500}
       alt='web'
       />
         </div>
         <div className='flex flex-col p-2'>
         <div className='text-5xl text-gray-900 tracking-wide font-bold'>Driven By Quality & </div>
         <div className='text-5xl text-gray-900 tracking-wide font-bold'>Dedicated</div>
         <div className='text-gray-500 w-1/2 tracking-wider py-11 px-2 text-lg'>Bibendum libero enim donec elementum inc eptos feugiat praesent parturient pote susp endisse. Dapibus eros sapien blandit nibher scelerisque ullamcorper</div>
         <div><button className='bg-green-600 text-white hover:bg-red-500 text-sm p-4 rounded-3xl'>Get a Quote</button></div>
         </div>
       </div>
     </section>

     <section>
       <div className='grid grid-cols-2 p-24 border-t border-black'>
        
         <div className='flex flex-col p-8 justify-center'>
         <div className='text-5xl text-gray-900 tracking-wide font-bold'>Make Your <p>Business Visible Online</p></div>
         <div className='text-gray-500 w-1/2 tracking-wider py-11  text-lg'>Bibendum libero enim donec elementum inc eptos feugiat praesent parturient pote susp endisse. Dapibus eros sapien blandit nibher scelerisque ullamcorper</div>
         <div><button className='bg-green-600 text-white hover:bg-red-500 text-sm py-4 px-8 rounded-md'>Get a Quote</button></div>
         </div>
         <div className='flex justify-center items-center'>
         <Image
       src={'/png3.webp'}
       width={500}
       height={500}
       alt='web'
       />
         </div>
       </div>
     </section>

     <section>
       
<div className='grid grid-cols-2 p-8 border-t border-black'>
<div>
 <Image
 src={'/img5.png'}
 width={900}
 height={500}
 alt='png'
 />
</div>
        <div className='flex flex-col p-24 justify-center'>
        <div className='text-5xl text-gray-900 tracking-wide font-bold leading-relaxed'>Generate 100% Traffic
<p>On Your Website</p></div>
        <div className='text-gray-500 w-1/2 tracking-wider py-11  text-lg'>Bibendum libero enim donec elementum inc eptos feugiat praesent parturient pote susp endisse. Dapibus eros sapien blandit nibher scelerisque ullamcorper</div>
        <div><button  className='bg-green-600 text-white hover:bg-red-500 text-sm py-4 px-8 rounded-md'>Get a Quote</button></div>
        </div>
       
      </div>
     </section>
     <section><Section2/></section>
     <Faq/>
   <section className=' relative'>
     <Form/>
   </section>
   <section>
     <Foot1/>
   </section>



   <section> <div className="container px-5 py-8 mx-auto flex items-center sm:flex-row flex-col">
   <a className="flex title-font font-medium items-center md:justify-start justify-center text-gray-900">
     <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" className="w-10 h-10 text-white p-2 bg-indigo-500 rounded-full" viewBox="0 0 24 24">
       <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
     </svg>
     <span className="ml-3 text-xl">Tailblocks</span>
   </a>
   <p className="text-sm text-gray-500 sm:ml-4 sm:pl-4 sm:border-l-2 sm:border-gray-200 sm:py-2 sm:mt-0 mt-4">© 2020 Tailblocks —
     <a href="https://twitter.com/knyttneve" className="text-gray-600 ml-1" rel="noopener noreferrer" target="_blank">@knyttneve</a>
   </p>
   <span className="inline-flex sm:ml-auto sm:mt-0 mt-4 justify-center sm:justify-start">
     <a className="text-gray-500">
       <svg fill="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" className="w-5 h-5" viewBox="0 0 24 24">
         <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"></path>
       </svg>
     </a>
     <a className="ml-3 text-gray-500">
       <svg fill="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" className="w-5 h-5" viewBox="0 0 24 24">
         <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"></path>
       </svg>
     </a>
     <a className="ml-3 text-gray-500">
       <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" className="w-5 h-5" viewBox="0 0 24 24">
         <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
         <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37zm1.5-4.87h.01"></path>
       </svg>
     </a>
     <a className="ml-3 text-gray-500">
       <svg fill="currentColor" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="0" className="w-5 h-5" viewBox="0 0 24 24">
         <path stroke="none" d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"></path>
         <circle cx="4" cy="4" r="2" stroke="none"></circle>
       </svg>
     </a>
   </span>
 </div></section>

    </div>
  )
}

export default MainSection
