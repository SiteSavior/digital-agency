'use client'
import React from 'react'
import Lottie, { useLottie } from "lottie-react";
import png1 from '@/public/png1.json'
import { FaFacebook, FaInstagram, FaLinkedin, FaPhone, FaUser, FaWhatsapp } from 'react-icons/fa'
import Image from 'next/image';
import { MdEmail, MdPhone } from 'react-icons/md';

const Slide = () => {
  
        const options = {
          animationData: png1,
          loop: true
        };
      
  return (
    <div className='  rounded-b-3xl  items-center bg-gradient-to-r from-blue-100 to-pink-100 w-full py-11 '>
       <div className=' flex bg-white drop-shadow-xl rounded-full w-4/5 justify-center items-center mx-auto px-2 '>
       <div className='flex justify-between  p-4 w-full items-center '>
       <div className='text-3xl font-bold text-black px-24'>Rapid Digital</div>
       </div>
       <div className='flex gap-4  w-full items-center justify-end px-11'>
       <div><button className='bg-green-600 text-white hover:bg-red-500 text-sm py-3 px-11 rounded-3xl'>Get a Quote</button></div>
       <div className=' bg-purple-700 rounded-full p-2 h-min'><FaPhone className=' rotate-90 text-white animate-pulse'/></div>
     <div className='flex gap-2 '>
       
       <div>Call us Now</div>
       <div>+91 45454545445</div>
       </div></div></div>
        <div className='grid grid-cols-2 pt-14'>

            <div className='flex p-11'>
            <div className='px-2 pt-24 justify-center'>
<div className=' text-blue-600 transform rotate-90 flex'>Social Media</div>

<div className='flex gap-4 text-4xl flex-col p-4 w-max text-green-600'>
<div className=''><FaFacebook/></div>
<div><FaWhatsapp/></div>
<div><FaInstagram/></div>
<div><FaLinkedin/></div>
</div>
</div>
<div className='flex flex-col gap-4 p-11'> 
            <div className="w-max flex py-5 items-center">
    <div className="flex-grow border-t border-red-600 w-24"></div>
    <span className="flex-shrink mx-4 text-red-600">Welcome to Agency</span>
</div>
                <div className=' tracking-wider font-bold  text-6xl text-gray-90'>
     <div className=' text-7xl'>We are Creative</div>
     <div className='flex'> <p className='text-pink-600'> Digital Marketing</p></div>
     <div>Agency</div>
     </div>
     <div className='p-4 text-sm tracking-wide'>We are 100+ professional software engineers with more than 10 years of experience in delivering superior products Believe it because you've seen it. Here are real numbers</div>

<div><button className='bg-red-600 text-white  rounded-3xl hover:bg-green-500 text-sm py-4 px-11' >Get a Quote</button></div>
</div>
</div>
<div className='flex justify-center items-center '>
        <div className='flex flex-col gap-9 rounde-3xl border-black  bg-pink-50 px-11 py-20 rounded-3xl border-2 '>
          <div className='text-3xl text-gray-900 font-bold tracking-wide'> Get a Quote</div>
          <div className='flex relative'>
          <input className='border-t border-l border-b w-96 border-black p-4 rounded-3xl' placeholder='Name' name='name' id='name'/>
          <div className='border border-gray-400 rounded-full p-5 absolute right-0'>
          <FaUser className=''/>
          </div>
          </div>
          <div className='flex relative'>
          <input className='border-t border-l border-b w-96 border-black p-4 rounded-3xl' placeholder='Email' name='name' id='name'/>
          <div className='border border-gray-400 rounded-full p-5 absolute right-0'>
          <MdEmail className=''/>
          </div>
          </div>
          <div className='flex w-96 relative'>
          <select  className='flex p-4 w-96 relative rounded-3xl border border-black' name="cars" id="cars">
  <option value="volvo">Services</option>
  <option value="saab">Web Development</option>
  <option value="mercedes">Seo Marketing</option>
  <option value="audi">Paid Ads</option>
</select>
</div>
          <div className='flex relative'>
          <input className='border-t border-l border-b w-96 border-black p-4 rounded-3xl' placeholder='Phone' name='name' id='name'/>
          <div className='border border-gray-400 rounded-full p-5 absolute right-0'>
          <MdPhone className=''/>
          </div>
          </div>
          <div className='p-4'><button className='bg-green-600 text-white hover:bg-red-500 text-sm py-4 px-8 rounded-3xl'>Get a Quote</button></div>
        </div>
         </div>
</div>
</div>
  )
}

export default Slide
