'use client'
import React, { useState } from 'react'
import { BiPhone } from 'react-icons/bi';
import { BsWhatsapp } from 'react-icons/bs';
import { FaUser } from 'react-icons/fa';
import { IoMdClose } from 'react-icons/io';
import { LuMessagesSquare } from 'react-icons/lu';
import { MdEmail, MdPhone } from 'react-icons/md';

const Form = () => {
    const [isVisible, setIsVisible] = useState(false);
    const [isVisible2, setIsVisible2] = useState(false);
    const [isVisible3, setIsVisible3] = useState(false);


  const toggleVisibility = () => {
    setIsVisible(!isVisible);
    setIsVisible2(!isVisible2);
  };
  
  return (
  
   <div>

    <div >{!isVisible2 ? <button onClick={toggleVisibility}  className='bg-green-600 animate-bounce text-white text-lg font-semibold hover:bg-red-600 hover:cursor-pointer p-4 fixed bottom-32 right-0 rounded-full'><LuMessagesSquare className='text-2xl'/></button> : <button onClick={toggleVisibility}  className='bg-green-600 text-white text-sm font-semibold hover:bg-red-600 hover:cursor-pointer p-4 fixed top-28 right-2 rounded-full'><IoMdClose /></button>}</div>
    <div ><button   className='bg-green-600 text-white text-lg font-semibold hover:bg-red-600 hover:cursor-pointer p-4 fixed bottom-9 right-0 rounded-full'><BsWhatsapp className='text-2xl'/></button></div>


   {isVisible && (
   <div className='flex justify-center items-center fixed right-5 bottom-24 z-50'>
   <div className='flex flex-col gap-9 rounde-3xl border-black  bg-gray-100 px-11 py-20 rounded-3xl border-2 '>
     <div className='text-3xl text-gray-900 font-bold tracking-wide'> Get a Quote</div>
     <div className='flex relative'>
     <input className='border-t border-l border-b w-96 border-black p-4 rounded-3xl' placeholder='Name' name='name' id='name'/>
     <div className='border border-gray-400 rounded-full p-5 absolute right-0'>
     <FaUser className=''/>
     </div>
     </div>
     <div className='flex relative'>
     <input className='border-t border-l border-b w-96 border-black p-4 rounded-3xl' placeholder='Email' name='name' id='name'/>
     <div className='border border-gray-400 rounded-full p-5 absolute right-0'>
     <MdEmail className=''/>
     </div>
     </div>
     <div className='flex w-96 relative'>
     <select  className='flex p-4 w-96 relative rounded-3xl border border-black' name="cars" id="cars">
<option value="volvo">Services</option>
<option value="saab">Web Development</option>
<option value="mercedes">Seo Marketing</option>
<option value="audi">Paid Ads</option>
</select>
</div>
     <div className='flex relative'>
     <input className='border-t border-l border-b w-96 border-black p-4 rounded-3xl' placeholder='Phone' name='name' id='name'/>
     <div className='border border-gray-400 rounded-full p-5 absolute right-0'>
     <MdPhone className=''/>
     </div>
     </div>
     <div className='p-4'><button className='bg-green-600 text-white hover:bg-red-500 text-sm py-4 px-8 rounded-3xl'>Get a Quote</button></div>
   </div>
    </div>
   )}
 </div>
  )
}

export default Form
